@echo off
chcp 65001 >nul
title 图片知识库整理工具 - 新手向导

echo ==================================================
echo   欢迎使用 图片知识库整理工具！
echo   我是你的智能助手，第一次使用我来帮你完成配置
echo   只需 6 步，大概 3 分钟
echo.
echo   如果你有任何问题，随时问我！
echo ==================================================
echo.

REM 检查 Python 是否安装
echo [1/5] 检查 Python 安装状态...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [错误] 未检测到 Python！
    echo.
    echo 请先安装 Python 3.8 或更高版本：
    echo   下载地址：https://www.python.org/downloads/
    echo.
    echo 安装时请务必勾选：Add Python to PATH
    echo.
    pause
    exit /b 1
)
echo [OK] Python 已安装
python --version
echo.

REM 检查 pip 是否可用
echo [2/5] 检查 pip 是否可用...
pip --version >nul 2>&1
if errorlevel 1 (
    echo [警告] pip 不可用，尝试修复...
    python -m ensurepip --upgrade
)
echo [OK] pip 可用
echo.

REM 安装核心依赖（先装核心，向导才能运行）
echo [3/5] 安装核心依赖（首次运行需要）...
echo    核心依赖较小，约 10MB，请稍候...
echo.
if exist "requirements_min.txt" (
    pip install -r requirements_min.txt -q
    if errorlevel 1 (
        echo.
        echo [错误] 核心依赖安装失败！
        echo 请手动运行：pip install -r requirements_min.txt
        echo.
        pause
        exit /b 1
    )
    echo [OK] 核心依赖安装完成
) else (
    echo [警告] requirements_min.txt 不存在，跳过
)
echo.

REM 安装完整依赖（主处理脚本需要）
echo [4/5] 安装完整依赖（可选，约 300MB）...
echo    这可能需要 2-5 分钟，请稍候...
echo    如果你只需要配置向导，可以按 Ctrl+C 跳过
echo.
if exist "requirements_full.txt" (
    pip install -r requirements_full.txt -q
    if errorlevel 1 (
        echo [警告] 部分完整依赖安装失败
        echo 但核心功能应该可以正常使用
        echo 后续可以手动运行：pip install -r requirements_full.txt
    ) else (
        echo [OK] 完整依赖安装完成
    )
) else (
    echo [警告] requirements_full.txt 不存在，跳过
)
echo.

REM 创建文件夹结构
echo [5/5] 创建文件夹结构...
if not exist "待处理图片" mkdir "待处理图片"
if not exist "已处理图片" mkdir "已处理图片"
if not exist "处理结果" mkdir "处理结果"
if not exist "config" mkdir "config"
if not exist "logs" mkdir "logs"
echo [OK] 文件夹创建完成
echo.

echo ==================================================
echo  环境检查完成！现在启动新手向导...
echo ==================================================
echo.
timeout /t 1 >nul

REM 启动向导
python setup_wizard.py

echo.
echo 向导运行完成。
echo.
echo 接下来你可以：
echo   1. 把要处理的图片放到「待处理图片」文件夹
echo   2. 对 WorkBuddy 说：处理新图片
echo.
pause
