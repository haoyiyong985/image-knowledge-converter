---
name: image-knowledge-converter
description: Transform mobile screenshots into organized knowledge documents. Extract text from screenshots (Xiaohongshu, WeChat Read, WeChat, etc.), classify by topic, and merge into Word/Markdown files. Supports batch processing, automatic archiving, and optional ima synchronization. Use this skill when users ask to convert screenshots to documents, organize knowledge base, or build structured knowledge from images.
version: 1.0
author: [Your Name]
tags: [image-processing, knowledge-management, document-generation, ocr, work-automation]
---

## Purpose

This skill automates the conversion of mobile screenshots into structured knowledge documents. It handles text extraction from various sources (Xiaohongshu, WeChat Read, WeChat, etc.), intelligent topic classification, document merging, and image archiving in a fully automated workflow.

The tool transforms scattered screenshots into organized, searchable knowledge bases with dual output formats (Word + Markdown) and optional synchronization to ima knowledge management platform.

## When to Use

Trigger this skill when users request any of the following:

**English triggers:**
- "Convert screenshots to documents"
- "Organize knowledge base from images"
- "Extract text from screenshots and save as Word"
- "Batch process screenshots"
- "Build knowledge documents from mobile screenshots"
- "Merge screenshot content into existing documents"
- "Image to document conversion"
- "Screenshot knowledge management"

**Chinese triggers:**
- "截图转文档"
- "图片知识库"
- "整理截图"
- "提取图片文字"
- "批量处理图片"
- "图片转Word"
- "建立知识库"
- "文档自动化"

**Related scenarios:**
- User has a folder of screenshots they want to organize
- User wants to merge content from multiple screenshots into one document
- User needs to extract text from images and save as structured documents
- User wants to build a personal knowledge base from mobile screenshots
- User needs to categorize and archive processed images

## Workflow

### Phase 1: Preparation

1. Verify project structure exists:
   - `待处理图片/<theme>/` - Source directory for new images
   - `已处理图片/<theme>/` - Archive directory for processed images
   - `处理结果/` - Output directory for Word and Markdown files

2. If structure doesn't exist, ask user to run initialization command: "初始化知识库"

### Phase 2: Scanning and Processing

3. Scan `待处理图片/` for subdirectories (themes):
   - Each subdirectory represents a theme/topic
   - List all image files within each theme directory

4. For each theme directory, process images in batch:

   **Step 4.1: Text Extraction**
   - Use WorkBuddy's image recognition capability to extract text from each image
   - Identify image source (Xiaohongshu, WeChat Read, WeChat, etc.)
   - Extract title, content, and any structured information

   **Step 4.2: Topic Classification**
   - Analyze extracted content to determine which existing document it belongs to
   - Check existing documents in `处理结果/` directory
   - Compare content against existing document titles and chapters
   - Classify as:
     - Existing document (e.g., "03_中医养生与食疗")
     - New document (requires new numbering: 05_xxx, 06_xxx, etc.)

   **Step 4.3: Content Merging**
   - If appending to existing document:
     - Read the corresponding `.md` file
     - Parse existing chapters to avoid duplication
     - Determine appropriate chapter to append or create new chapter
     - Append new content without overwriting existing sections
   
   - If creating new document:
     - Generate document title from theme content
     - Create new `.md` and `.docx` files with next available number
     - Add proper document structure (title, chapters, etc.)

   **Step 4.4: Document Generation**
   - Generate/updated `.md` file with merged content
   - Generate/updated `.docx` file from Markdown content
   - Ensure proper formatting, headings, and structure

   **Step 4.5: Image Archiving**
   - Move processed images from `待处理图片/<theme>/` to `已处理图片/<theme>/`
   - Maintain original filenames
   - Create subdirectory in archive if it doesn't exist

### Phase 3: Cleanup and Sync

5. Run `scripts/auto_process.py` to:
   - Scan `处理结果/` for all existing documents
   - Parse document structure (titles, chapters, word counts)
   - Update startup prompt file with current document list
   - Print summary of processed images and updated documents

6. Optional ima synchronization (if configured):
   - Check if `ima_config.txt` exists with valid credentials
   - For each updated `.md` file:
     - Check if already synced to ima (by tracking file modification time)
     - If new or modified, call `ima_sync.py` to sync
     - Log sync status (success/skip)

### Phase 4: Completion Report

7. Generate completion summary:
   - Number of images processed
   - Documents created/updated
   - Files generated (Word + Markdown)
   - Images archived
   - ima sync status (if applicable)
   - Any warnings or errors encountered

## Usage Commands

### Main Commands

**Processing Commands:**
- "处理新图片" → Scan all `待处理图片/<theme>/` directories and process all pending images
- "处理待处理图片/<主题名>" → Process only images in the specified theme directory
- "批量处理截图" → Batch process all screenshots in pending directories

**Management Commands:**
- "查看现有文档" → List all documents in `处理结果/` with titles, chapters, and word counts
- "初始化知识库" → Create required directory structure and template files
- "查看处理状态" → Show current pending images and recently processed files

**Optimization Commands:**
- "工具优化" → Analyze current workflow and suggest improvements
- "优化分类逻辑" → Refine topic classification algorithm
- "添加新模板" → Create custom Word/Markdown templates
- "调试模式" → Enable verbose logging for troubleshooting

**Configuration Commands:**
- "配置ima同步" → Guide user through ima API credential setup
- "验证ima凭证" → Check if ima credentials are valid
- "测试OCR" → Test image recognition with a sample image

## Key Features

### Core Features

1. **Automatic Image Scanning**
   - Recursive scan of theme directories
   - Support for multiple image formats (JPG, PNG, WEBP, etc.)
   - Real-time count of pending images

2. **Intelligent Text Extraction**
   - OCR capability for various image sources
   - Structured data extraction (title, content, metadata)
   - Handling of multi-line and formatted text

3. **Smart Topic Classification**
   - Content analysis to match existing documents
   - Automatic document numbering (01_xxx, 02_xxx, etc.)
   - Duplicate detection to prevent content repetition

4. **Content Merging**
   - Append to existing documents without overwriting
   - Intelligent chapter placement
   - Maintains document structure and formatting

5. **Dual Output Format**
   - Markdown (.md) for version control and editing
   - Word (.docx) for sharing and printing
   - Synchronized updates between formats

6. **Automatic Archiving**
   - Move processed images to archive directory
   - Maintain original filenames
   - Organize by theme

7. **Startup Prompt Auto-Refresh**
   - Automatically update startup prompt with document list
   - Maintain current document structure and statistics
   - Enable AI to have context of existing knowledge base

### Advanced Features

8. **ima Synchronization (Optional)**
   - Automatic sync of documents to ima knowledge platform
   - Differential sync (only updated files)
   - Credential management and validation

9. **Template System**
   - Custom Word templates for different document types
   - Markdown structure templates
   - Extensible template library

10. **Batch Processing**
    - Process hundreds of images in one command
    - Progress reporting and error handling
    - Resumable processing after interruption

## Bundled Resources

### Scripts Directory

**auto_process.py**
- Purpose: Scan project structure and refresh startup prompt
- Usage: Automatically called after processing is complete
- Output: Updated startup prompt file with current document list
- No user interaction required

**packager.py**
- Purpose: Package skill for distribution
- Usage: `python packager.py` to generate skill.zip
- Output: Compressed skill package ready for sharing
- Validates skill structure before packaging

**sync_tool.py**
- Purpose: Core image processing and document generation logic
- Usage: AI will execute this script during processing workflow
- Features: OCR, classification, merging, archiving
- Note: This script is a template that AI will adapt to specific needs

### References Directory

**usage-guide.md**
- Purpose: Detailed step-by-step tutorial for new users
- Contents: Installation, configuration, first use, common scenarios
- Target audience: Beginners unfamiliar with WorkBuddy skills
- Language: Chinese with screenshots where applicable

**faq.md**
- Purpose: Common issues and solutions
- Contents: 
  - Troubleshooting OCR failures
  - Handling duplicate content
  - Configuration issues
  - Performance optimization
  - ima sync problems
- Maintained based on user feedback

**examples.md**
- Purpose: Real-world usage scenarios and examples
- Contents:
  - Example 1: Processing Xiaohongshu screenshots
  - Example 2: Merging WeChat Read notes
  - Example 3: Building a nutrition knowledge base
  - Example 4: Batch processing 100+ images
- Demonstrates skill capabilities in practice

### Assets Directory

**templates/word_template.docx**
- Purpose: Default Word document template
- Features:
  - Professional formatting
  - Table of contents
  - Page numbers
  - Header/footer
- Users can customize this for their branding

**templates/md_template.md**
- Purpose: Default Markdown structure
- Features:
  - H1-H6 heading hierarchy
  - Table formatting
  - Code block syntax
  - Metadata header
- Compatible with Typora and other Markdown editors

**prompts/classify_prompt.txt**
- Purpose: AI prompt for topic classification
- Contains instructions for content analysis
- Helps AI determine which document content belongs to
- Improves classification accuracy

**prompts/extract_prompt.txt**
- Purpose: AI prompt for content extraction
- Contains instructions for OCR and data extraction
- Defines output format for extracted content
- Optimized for various image sources

## Dependencies

### Required Dependencies

- **Python 3.8+**
  - For executing bundled scripts
  - Download: https://www.python.org/downloads/

- **python-docx library**
  - For generating Word documents
  - Installation: `pip install python-docx`

- **WorkBuddy with image recognition capability**
  - For OCR and image analysis
  - Requires multi-modal AI model support

### Optional Dependencies

- **ima PC Client**
  - For knowledge synchronization
  - Download: https://ima.qq.com
  - Account required for API access

- **ima OpenAPI Credentials**
  - For automatic synchronization
  - Get credentials at: https://ima.qq.com/agent-interface
  - Configure in `ima_config.txt`

### System Requirements

- **Operating System**: Windows, macOS, or Linux
- **Disk Space**: Minimum 100MB for skill files + user data
- **Network**: Internet connection required for:
  - Initial skill installation
  - ima synchronization (if enabled)
  - Image recognition (if using cloud-based OCR)

## Troubleshooting

### Common Issues

**Issue: "No images found in pending directories"**
- Solution: 
  - Verify images are placed in `待处理图片/<theme>/` directories
  - Ensure directory names are valid (no special characters)
  - Check file permissions

**Issue: "OCR accuracy is poor"**
- Solution:
  - Ensure images are clear and high-resolution
  - Try cropping images to focus on text areas
  - Use images from supported sources (Xiaohongshu, WeChat Read, etc.)
  - Report persistent issues in skill repository

**Issue: "Duplicate content in documents"**
- Solution:
  - Check existing chapters before processing (Phase 2, Step 4.3)
  - Use "查看现有文档" command to review current content
  - Manually edit documents to remove duplicates
  - Improve classification logic with "工具优化" command

**Issue: "ima synchronization fails"**
- Solution:
  - Verify `ima_config.txt` contains valid credentials
  - Run "验证ima凭证" command to test connection
  - Check internet connection
  - Ensure ima account is active

**Issue: "Word document formatting is incorrect"**
- Solution:
  - Customize `assets/templates/word_template.docx`
  - Ensure python-docx library is properly installed
  - Check for corrupted images in source directory

For more detailed troubleshooting, see `references/faq.md`.

## Version History

**v1.0 (2026-03-17)**
- Initial release
- Core features: image scanning, OCR, classification, merging, archiving
- Dual output: Word + Markdown
- Optional ima synchronization
- Startup prompt auto-refresh
- Comprehensive documentation and examples

**Planned for v1.1**
- Enhanced classification algorithm with ML
- Support for more image sources
- Custom template marketplace
- Real-time processing progress
- Multi-language support

---

**Need Help?**
- Report issues: [GitHub Repository URL]
- Join community: [Discord/WeChat Group Link]
- Documentation: [Online Documentation URL]
