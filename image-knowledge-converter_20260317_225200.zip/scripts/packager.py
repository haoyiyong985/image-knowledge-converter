#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
打包脚本 - 将 skill 打包成可分发的 ZIP 文件
"""

import os
import zipfile
from pathlib import Path
from datetime import datetime

def package_skill():
    """打包 skill 为 ZIP 文件"""
    
    # 获取 skill 根目录
    skill_dir = Path(__file__).parent.parent
    skill_name = skill_dir.name
    
    # 输出目录
    output_dir = skill_dir.parent / "dist"
    output_dir.mkdir(exist_ok=True)
    
    # ZIP 文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = output_dir / f"{skill_name}_{timestamp}.zip"
    
    # 需要打包的文件和目录
    files_to_include = [
        "SKILL.md",
        "README.md",
        "LICENSE",
        "scripts/",
        "references/",
        "assets/",
    ]
    
    print(f"============================================================")
    print(f"  打包 Skill: {skill_name}")
    print(f"============================================================")
    
    # 创建 ZIP
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for item in files_to_include:
            item_path = skill_dir / item
            
            if item_path.exists():
                if item_path.is_file():
                    # 打包文件
                    zipf.write(item_path, item)
                    print(f"  [添加] {item}")
                elif item_path.is_dir():
                    # 打包目录
                    for root, dirs, files in os.walk(item_path):
                        for file in files:
                            file_path = Path(root) / file
                            # 计算相对路径
                            rel_path = file_path.relative_to(skill_dir)
                            zipf.write(file_path, rel_path)
                            print(f"  [添加] {rel_path}")
            else:
                print(f"  [跳过] {item}（文件不存在）")
    
    print(f"\n[完成] 打包成功！")
    print(f"       文件: {zip_filename}")
    print(f"       大小: {zip_filename.stat().st_size / 1024:.1f} KB")
    print(f"\n下一步：")
    print(f"       1. 测试解压和安装")
    print(f"       2. 上传到 GitHub Releases")
    print(f"       3. 提交到腾讯云技能市场")
    print(f"============================================================")

if __name__ == "__main__":
    package_skill()
