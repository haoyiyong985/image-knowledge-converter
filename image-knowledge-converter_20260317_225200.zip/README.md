# 图片知识库转化工具 (Image Knowledge Converter) v1.0

> 自动将手机截图转换成结构化的 Word 和 Markdown 知识文档

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![WorkBuddy Skill](https://img.shields.io/badge/WorkBuddy-Skill-green.svg)](https://www.codebuddy.cn/docs/cli/skills)
[![Version](https://img.shields.io/badge/Version-1.0-orange.svg)](https://github.com/yourname/workbuddy-image-knowledge-converter/releases)

## ✨ 特性

- 📸 **智能 OCR**：自动识别小红书、微信读书、微信等来源的截图
- 🎯 **智能分类**：自动判断内容主题，合并到对应文档
- 📝 **双格式输出**：同时生成 Word 和 Markdown 文档
- 🗂️ **自动归档**：处理完的图片自动移到归档目录
- 🔄 **增量更新**：追加内容，不覆盖已有章节
- ☁️ **ima 同步**：可选自动同步到腾讯 ima 知识库
- 🚀 **批量处理**：一次处理数百张图片
- 🛠️ **模板系统**：支持自定义 Word 和 Markdown 模板

## 🎯 适用场景

- 整理小红书保存的健康知识截图
- 合并微信读书的笔记截图
- 归档微信群的专业文章
- 构建个人知识库
- 图片转文档自动化

## 📦 安装

### 方式一：从 ZIP 导入（推荐）

1. 下载最新版 [image-knowledge-converter.zip](releases)
2. 在 WorkBuddy 中进入「Claw 设置」→「Skills 管理」
3. 点击「导入 Skills」，选择 ZIP 文件
4. 点击「立即导入」

### 方式二：从 Git 仓库导入

1. 复制仓库地址：`https://github.com/yourname/workbuddy-image-knowledge-converter.git`
2. 在 WorkBuddy「Skills 管理」页面粘贴地址
3. 点击「立即导入」

## 🚀 快速开始

### 1. 初始化项目

安装完成后，发送以下命令：

```
初始化知识库
```

系统会自动创建目录结构：

```
你的项目/
├── 待处理图片/        ← 新截图放这里
│   ├── 养生/
│   ├── 饮食/
│   └── 健康/
├── 已处理图片/        ← 处理完的图片移到这里
└── 处理结果/          ← 生成的文档在这里
```

### 2. 放入截图

将手机截图放入 `待处理图片/<主题名>/` 文件夹

### 3. 开始处理

在 WorkBuddy 中说：

```
处理新图片
```

等待几秒钟，完成！

### 4. 查看结果

在 `处理结果/` 文件夹查看生成的 Word 和 Markdown 文档。

## 📖 使用文档

详细使用教程请查看：[使用指南 (中文)](references/usage-guide.md)

- [快速开始](references/usage-guide.md#一快速开始)
- [安装配置](references/usage-guide.md#二安装配置)
- [常用操作](references/usage-guide.md#四常用操作)
- [高级功能](references/usage-guide.md#五高级功能)
- [常见问题](references/usage-guide.md#六常见问题)

## 💻 系统要求

- **WorkBuddy**：支持 skills 功能
- **Python 3.8+**：用于运行辅助脚本
- **python-docx**：生成 Word 文档（`pip install python-docx`）
- **可选**：ima PC 客户端（用于同步功能）

## 🎮 常用命令

```
处理新图片              → 扫描并处理所有待处理图片
处理待处理图片/<主题名>  → 只处理指定主题文件夹的图片
查看现有文档            → 列出所有文档和章节
初始化知识库            → 创建目录结构
查看处理状态            → 显示当前状态
工具优化                → 分析并改进工具能力
验证ima凭证             → 测试 ima API 连接
```

## 🌟 高级功能

### ima 同步（可选）

将文档自动同步到腾讯 ima 知识库，支持智能检索和问答。

**配置步骤：**
1. 访问 https://ima.qq.com/agent-interface
2. 获取 Client ID 和 API Key
3. 创建 `ima_config.txt` 文件，填入凭证
4. 运行"验证ima凭证"测试连接

### 自定义模板

- `assets/templates/word_template.docx` - Word 文档模板
- `assets/templates/md_template.md` - Markdown 文档模板

可以修改模板来调整文档格式、字体、样式等。

## 📚 相关文档

- [使用指南 (中文)](references/usage-guide.md) - 详细教程
- [常见问题](references/faq.md) - 问题排查
- [使用示例](references/examples.md) - 实际案例
- [SKILL.md](SKILL.md) - Skill 定义文档

## 🤝 贡献

欢迎贡献代码、报告问题或提出建议！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 提交 Pull Request

## 📄 许可证

本项目采用 [MIT 许可证](LICENSE) 开源。

## 📮 联系方式

- **GitHub Issues**：报告问题和建议
- **微信群**：[点击加入](your-group-link)
- **邮箱**：your-email@example.com

## 🙏 致谢

感谢 WorkBuddy 团队提供的强大技能系统！

---

## 📊 版本历史

### v1.0 (2026-03-17)

**新增功能：**
- ✅ 图片文字识别（OCR）
- ✅ 智能主题分类
- ✅ 文档合并与生成
- ✅ 自动图片归档
- ✅ 双格式输出（Word + Markdown）
- ✅ 启动提示词自动刷新
- ✅ ima 同步（可选）
- ✅ 模板系统

**已知问题：**
- OCR 准确度依赖图片质量
- 分类逻辑可进一步优化

**下一步计划：**
- 机器学习分类算法
- 支持更多图片来源
- 实时处理进度显示
- 多语言支持

---

**⭐ 如果这个工具对你有帮助，请点个 Star 支持！**
